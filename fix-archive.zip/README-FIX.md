# Инструкция по применению исправлений

## Шаг 1: Распаковать архив
Распакуйте содержимое архива в корень вашего репозитория (там, где `package.json`).

Файлы перезапишут:
- `astro.config.mjs`
- `.gitignore`
- `src/pages/about/index.astro`
- `src/pages/editorial-policy/index.astro`
- `src/content/articles/bankrotstvo-kak-sistema.md`

## Шаг 2: Удалить старую сборку из Git
```bash
git rm -rf dist/
git commit -m "remove dist from repo"
```

## Шаг 3: Установить sitemap (если ещё не установлен)
```bash
npm install @astrojs/sitemap
```

## Шаг 4: Собрать
```bash
npm run build
```

## Шаг 5: Проверить
Убедитесь, что в `dist/` появились:
- `sitemap.xml` (должен быть XML, не HTML)
- `robots.txt` (должен быть текстовым)

## Что исправлено
- Опечатки в about, editorial-policy, bankrotstvo
- sitemap теперь генерируется через `@astrojs/sitemap`
- `.gitignore` теперь исключает `dist/` и `.astro/`
